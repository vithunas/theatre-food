/**
 * Shared data layer.
 *
 * The single place any app reads or writes persisted state. Components must use
 * these helpers and never touch localStorage directly.
 *
 * Storage is localStorage (per-app source of truth). Because localStorage is
 * origin-scoped and the three apps run on different ports, every write is also
 * mirrored over a WebSocket relay (see sync-server.js) so all apps stay in sync.
 *
 * Keys:
 *   tfo_orders   - Order[]
 *   tfo_menu     - MenuItem[] (with live stock counts)
 *   tfo_settings - { theatreName, orderingEnabled }
 */
import { SEED_MENU, stockLevelFor } from "./constants.js";

export const KEYS = {
  orders: "tfo_orders",
  menu: "tfo_menu",
  settings: "tfo_settings",
};

const SYNC_URL = "ws://localhost:5180";
const DEFAULT_SETTINGS = { theatreName: "Starlight Cinema", orderingEnabled: true };

/** @type {Set<(key: string) => void>} */
const listeners = new Set();
let socket = null;

function notify(key) {
  for (const cb of listeners) {
    try {
      cb(key);
    } catch {
      /* listener errors are isolated */
    }
  }
}

/**
 * Read and parse a JSON value from localStorage.
 * @template T
 * @param {string} key
 * @param {T} fallback
 * @returns {T}
 */
function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

/**
 * Write a value to localStorage and (optionally) broadcast it to other apps.
 * @param {string} key
 * @param {unknown} value
 * @param {{ broadcast?: boolean }} [opts]
 */
function persist(key, value, { broadcast = true } = {}) {
  const json = JSON.stringify(value);
  try {
    localStorage.setItem(key, json);
  } catch {
    /* storage full / unavailable */
  }
  if (broadcast && socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ type: "set", key, value: json }));
  }
  notify(key);
}

/** Apply a write that originated from another app (do not re-broadcast). */
function applyRemote(key, json) {
  if (json == null) return;
  try {
    localStorage.setItem(key, json);
    notify(key);
  } catch {
    /* ignore */
  }
}

function connectSync() {
  if (typeof window === "undefined" || !("WebSocket" in window)) return;
  try {
    socket = new WebSocket(SYNC_URL);
  } catch {
    return;
  }
  socket.addEventListener("open", () => {
    socket.send(JSON.stringify({ type: "hello" }));
  });
  socket.addEventListener("message", (ev) => {
    let msg;
    try {
      msg = JSON.parse(ev.data);
    } catch {
      return;
    }
    if (msg.type === "snapshot") {
      for (const [k, v] of Object.entries(msg.state || {})) applyRemote(k, v);
    } else if (msg.type === "set" && typeof msg.key === "string") {
      applyRemote(msg.key, msg.value);
    }
  });
  socket.addEventListener("close", () => setTimeout(connectSync, 1500));
  socket.addEventListener("error", () => {
    try {
      socket.close();
    } catch {
      /* ignore */
    }
  });
}

if (typeof window !== "undefined") {
  connectSync();
  // Same-origin, cross-tab updates (different ports are handled by the relay).
  window.addEventListener("storage", (e) => {
    if (e.key && Object.values(KEYS).includes(e.key)) notify(e.key);
  });
}

/**
 * Subscribe to data changes (local writes and remote/cross-app writes).
 * @param {(key: string) => void} cb
 * @returns {() => void} unsubscribe
 */
export function subscribe(cb) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

// ---------------------------------------------------------------------------
// Orders
// ---------------------------------------------------------------------------

/** @returns {Array<object>} all orders, newest first. */
export function getOrders() {
  return read(KEYS.orders, []);
}

/**
 * Insert or update an order (matched by id) and persist.
 * @param {object} order
 * @returns {object} the saved order
 */
export function saveOrder(order) {
  const orders = getOrders();
  const idx = orders.findIndex((o) => o.id === order.id);
  if (idx >= 0) orders[idx] = order;
  else orders.unshift(order);
  persist(KEYS.orders, orders);
  return order;
}

/**
 * Advance or set an order's status.
 * @param {string} id
 * @param {string} status
 * @returns {object|null} the updated order, or null if not found
 */
export function updateOrderStatus(id, status) {
  const orders = getOrders();
  const idx = orders.findIndex((o) => o.id === id);
  if (idx < 0) return null;
  orders[idx] = { ...orders[idx], status, updatedAt: Date.now() };
  persist(KEYS.orders, orders);
  return orders[idx];
}

/**
 * Save feedback ({ rating, comment }) onto an order.
 * @param {string} id
 * @param {{rating:number, comment?:string}} feedback
 */
export function saveFeedback(id, feedback) {
  const orders = getOrders();
  const idx = orders.findIndex((o) => o.id === id);
  if (idx < 0) return null;
  orders[idx] = { ...orders[idx], feedback, updatedAt: Date.now() };
  persist(KEYS.orders, orders);
  return orders[idx];
}

// ---------------------------------------------------------------------------
// Menu / inventory
// ---------------------------------------------------------------------------

/** @returns {Array<object>} the menu with live stock counts. */
export function getMenu() {
  return read(KEYS.menu, []);
}

/** Persist the whole menu array. */
export function saveMenu(menu) {
  persist(KEYS.menu, menu);
  return menu;
}

/**
 * Adjust an item's stock by a delta (negative to sell, positive to restock).
 * Recomputes the stockLevel bucket.
 * @param {string} itemId
 * @param {number} delta
 */
export function updateStock(itemId, delta) {
  const menu = getMenu();
  const idx = menu.findIndex((m) => m.id === itemId);
  if (idx < 0) return;
  const stock = Math.max(0, (menu[idx].stock || 0) + delta);
  menu[idx] = { ...menu[idx], stock, stockLevel: stockLevelFor(stock) };
  persist(KEYS.menu, menu);
}

/**
 * Patch a single menu item (admin edits). Recomputes stockLevel if stock changes.
 * @param {string} itemId
 * @param {object} patch
 */
export function updateMenuItem(itemId, patch) {
  const menu = getMenu();
  const idx = menu.findIndex((m) => m.id === itemId);
  if (idx < 0) return;
  const merged = { ...menu[idx], ...patch };
  merged.stockLevel = stockLevelFor(merged.stock);
  menu[idx] = merged;
  persist(KEYS.menu, menu);
}

/** Append a new menu item (admin). */
export function addMenuItem(item) {
  const menu = getMenu();
  const id = `ITEM-${Date.now()}`;
  const next = {
    id,
    active: true,
    description: "",
    ...item,
    stockLevel: stockLevelFor(item.stock || 0),
  };
  menu.push(next);
  persist(KEYS.menu, menu);
  return next;
}

/** Seed the menu and default settings on first run. */
export function seedMenuIfEmpty() {
  if (getMenu().length === 0) saveMenu(SEED_MENU);
  if (!localStorage.getItem(KEYS.settings)) persist(KEYS.settings, DEFAULT_SETTINGS);
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

/** @returns {{theatreName:string, orderingEnabled:boolean}} */
export function getSettings() {
  return read(KEYS.settings, DEFAULT_SETTINGS);
}

/** Merge and persist settings. */
export function saveSettings(patch) {
  const next = { ...getSettings(), ...patch };
  persist(KEYS.settings, next);
  return next;
}
