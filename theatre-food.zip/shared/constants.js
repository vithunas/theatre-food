/**
 * Shared constants: menu seed data and order status flow.
 * Imported by all three apps.
 */

/** Order status flow, in order. */
export const STATUS_FLOW = [
  "placed",
  "confirmed",
  "preparing",
  "ready",
  "delivering",
  "delivered",
];

/** Human-readable labels for each status. */
export const STATUS_LABELS = {
  placed: "Order placed",
  confirmed: "Confirmed",
  preparing: "Preparing",
  ready: "Ready",
  delivering: "On the way",
  delivered: "Delivered",
};

/** Menu categories used by the customer filter pills. */
export const CATEGORIES = ["Snacks", "Meals", "Drinks", "Combos", "Desserts"];

/** GST rate applied to order subtotals. */
export const GST_RATE = 0.05;

/**
 * Derive a stock level bucket from a raw stock count.
 * @param {number} stock
 * @returns {"ok"|"low"|"out"}
 */
export function stockLevelFor(stock) {
  if (stock <= 0) return "out";
  if (stock <= 8) return "low";
  return "ok";
}

const RAW_MENU = [
  // Snacks
  { name: "Classic salted popcorn", category: "Snacks", price: 120, stock: 50, description: "Freshly popped, lightly salted — the cinema classic." },
  { name: "Cheese nachos", category: "Snacks", price: 180, stock: 30, description: "Crisp tortilla chips loaded with warm cheese sauce." },
  { name: "Masala fries", category: "Snacks", price: 150, stock: 8, description: "Crinkle-cut fries tossed in tangy masala spice." },
  { name: "Salted peanuts", category: "Snacks", price: 80, stock: 3, description: "Roasted and salted, perfect for nibbling." },
  { name: "Chilli paneer bites", category: "Snacks", price: 200, stock: 0, description: "Crispy paneer cubes in a spicy chilli glaze." },

  // Meals
  { name: "Veg burger", category: "Meals", price: 220, stock: 20, description: "Grilled veg patty, lettuce and house sauce in a soft bun." },
  { name: "Chicken wrap", category: "Meals", price: 280, stock: 15, description: "Spiced chicken, crunchy salad and mayo in a warm wrap." },
  { name: "Paneer tikka box", category: "Meals", price: 260, stock: 8, description: "Smoky paneer tikka with mint chutney and rice." },

  // Drinks
  { name: "Cold coffee", category: "Drinks", price: 150, stock: 25, description: "Chilled, frothy and lightly sweetened." },
  { name: "Fresh lime soda", category: "Drinks", price: 90, stock: 40, description: "Zesty lime over fizzy soda — sweet or salted." },
  { name: "Mango shake", category: "Drinks", price: 140, stock: 12, description: "Thick alphonso mango blended with milk." },
  { name: "Mineral water", category: "Drinks", price: 40, stock: 100, description: "Chilled 500ml bottle." },

  // Combos
  { name: "Classic movie combo", category: "Combos", price: 240, stock: 20, description: "Classic popcorn paired with a cold coffee." },
  { name: "Date night box", category: "Combos", price: 420, stock: 10, description: "Cheese nachos with two cold coffees to share." },
  { name: "Family pack", category: "Combos", price: 480, stock: 15, description: "Two popcorns and two drinks for the whole row." },

  // Desserts
  { name: "Chocolate brownie", category: "Desserts", price: 130, stock: 18, description: "Warm fudgy brownie with a molten centre." },
  { name: "Ice cream cup", category: "Desserts", price: 110, stock: 2, description: "Creamy vanilla scoop in a handy cup." },
  { name: "Gulab jamun cup", category: "Desserts", price: 100, stock: 22, description: "Two warm gulab jamuns soaked in saffron syrup." },
];

/**
 * The seed menu, with stable ids and derived stockLevel.
 * @type {Array<{id:string,name:string,category:string,price:number,description:string,stock:number,stockLevel:"ok"|"low"|"out",active:boolean}>}
 */
export const SEED_MENU = RAW_MENU.map((item, i) => ({
  id: `ITEM-${String(i + 1).padStart(2, "0")}`,
  ...item,
  stockLevel: stockLevelFor(item.stock),
  active: true,
}));
