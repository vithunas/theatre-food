/**
 * Cross-port data sync relay.
 *
 * localStorage is scoped per-origin, so the customer (5173), admin (5174) and
 * kitchen (5175) apps cannot see each other's storage. This tiny WebSocket relay
 * mirrors every write across all connected apps so they share one live data set.
 *
 * Protocol (JSON messages):
 *   client -> server  { type: "set", key, value }   broadcast a write
 *   client -> server  { type: "hello" }              ask for the current snapshot
 *   server -> client  { type: "snapshot", state }    full {key: value} map on connect
 *   server -> client  { type: "set", key, value }    a write made by another app
 *
 * The relay keeps the latest value per key in memory only. localStorage remains
 * the per-app source of truth; this just keeps the copies consistent.
 */
import { WebSocketServer } from "ws";

const PORT = 5180;
const wss = new WebSocketServer({ port: PORT });

/** @type {Record<string, string>} latest value per key (JSON strings) */
const state = {};

function broadcast(sender, message) {
  const data = JSON.stringify(message);
  for (const client of wss.clients) {
    if (client !== sender && client.readyState === 1) {
      client.send(data);
    }
  }
}

wss.on("connection", (socket) => {
  // Send the current shared state to the newly connected app.
  socket.send(JSON.stringify({ type: "snapshot", state }));

  socket.on("message", (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (msg.type === "hello") {
      socket.send(JSON.stringify({ type: "snapshot", state }));
    } else if (msg.type === "set" && typeof msg.key === "string") {
      state[msg.key] = msg.value;
      broadcast(socket, { type: "set", key: msg.key, value: msg.value });
    }
  });
});

console.log(`[sync] relay listening on ws://localhost:${PORT}`);
