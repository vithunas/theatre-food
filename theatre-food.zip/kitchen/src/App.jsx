import { useEffect, useRef, useState } from "react";
import { ChefHat, ExternalLink, CheckCheck } from "lucide-react";
import { getOrders, updateOrderStatus, subscribe } from "@shared/data.js";

const COLUMNS = [
  { key: "new", title: "New", statuses: ["placed", "confirmed"] },
  { key: "progress", title: "In progress", statuses: ["preparing"] },
  { key: "ready", title: "Ready", statuses: ["ready", "delivering"] },
];

const NEXT = {
  placed: { label: "Confirm", next: "confirmed" },
  confirmed: { label: "Start preparing", next: "preparing" },
  preparing: { label: "Mark ready", next: "ready" },
  ready: { label: "Out for delivery", next: "delivering" },
  delivering: { label: "Mark delivered", next: "delivered" },
};

function accent(status) {
  if (status === "preparing") return "var(--amber)";
  if (status === "ready" || status === "delivering") return "var(--success)";
  return "var(--gold)"; // placed / confirmed
}

function minutesAgo(ts) {
  const m = Math.floor((Date.now() - ts) / 60000);
  return m < 1 ? "just now" : `${m} min ago`;
}

function beep() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    beep._ctx = beep._ctx || new Ctx();
    const ctx = beep._ctx;
    if (ctx.state === "suspended") ctx.resume();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.connect(g);
    g.connect(ctx.destination);
    o.type = "sine";
    o.frequency.value = 880;
    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.28);
    o.start();
    o.stop(ctx.currentTime + 0.3);
  } catch {
    /* audio unavailable */
  }
}

function useClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return now.toLocaleTimeString("en-GB");
}

export default function App() {
  const [orders, setOrders] = useState(() => getOrders());
  const [, setTick] = useState(0);
  const prevIds = useRef(null);
  const clock = useClock();

  // Poll + subscribe to the shared data layer.
  useEffect(() => {
    const refresh = () => setOrders(getOrders());
    const unsub = subscribe(refresh);
    const poll = setInterval(refresh, 5000);
    return () => {
      unsub();
      clearInterval(poll);
    };
  }, []);

  // "X min ago" refresh every 30s.
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 30000);
    return () => clearInterval(t);
  }, []);

  // Beep when a brand-new order appears (skip the very first load).
  useEffect(() => {
    const ids = new Set(orders.filter((o) => o.status !== "delivered").map((o) => o.id));
    if (prevIds.current) {
      for (const id of ids) {
        if (!prevIds.current.has(id)) {
          beep();
          break;
        }
      }
    }
    prevIds.current = ids;
  }, [orders]);

  const active = orders.filter((o) => o.status !== "delivered");

  const markAllReady = () => {
    orders.filter((o) => o.status === "preparing").forEach((o) => updateOrderStatus(o.id, "ready"));
  };

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center justify-between border-b border-hairline px-6 py-4">
        <div className="flex items-center gap-2">
          <ChefHat size={22} className="text-gold" />
          <span className="font-heading text-xl text-primary">Kitchen</span>
        </div>
        <span className="font-heading text-3xl tabular-nums text-primary">{clock}</span>
        <div className="flex items-center gap-4">
          <span className="text-sm text-muted">
            <span className="text-lg font-medium text-primary">{active.length}</span> active
          </span>
          <button onClick={markAllReady} className="btn-ghost flex items-center gap-2 px-3 py-2 text-sm">
            <CheckCheck size={15} /> Mark all ready
          </button>
          <a
            href="http://localhost:5174"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1 text-xs text-muted transition-colors hover:text-gold"
          >
            Admin <ExternalLink size={12} />
          </a>
        </div>
      </header>

      <div className="grid flex-1 grid-cols-3 gap-4 overflow-hidden p-4">
        {COLUMNS.map((col) => {
          const cards = active
            .filter((o) => col.statuses.includes(o.status))
            .sort((a, b) => a.placedAt - b.placedAt);
          return (
            <section key={col.key} className="flex min-h-0 flex-col rounded-2xl border border-hairline bg-surface">
              <div className="flex items-center justify-between border-b border-hairline px-4 py-3">
                <h2 className="text-base text-primary">{col.title}</h2>
                <span className="rounded-full bg-elevated px-2 py-0.5 text-sm text-muted">{cards.length}</span>
              </div>
              <div className="flex-1 space-y-3 overflow-y-auto p-3">
                {cards.length === 0 && (
                  <p className="py-10 text-center text-sm text-muted">Nothing here.</p>
                )}
                {cards.map((o) => {
                  const action = NEXT[o.status];
                  return (
                    <article
                      key={o.id}
                      className="card-enter rounded-xl border border-hairline bg-elevated p-4"
                      style={{ borderLeft: `4px solid ${accent(o.status)}` }}
                    >
                      <div className="flex items-baseline justify-between">
                        <h3 className="font-heading text-2xl text-primary">{o.id.replace("ORD-", "#")}</h3>
                        <span className="text-xs text-muted">{minutesAgo(o.placedAt)}</span>
                      </div>
                      <p className="text-sm text-muted">Seat {o.seatNumber}</p>

                      <ul className="my-3 space-y-1">
                        {o.items.map((i) => (
                          <li key={i.id} className="flex items-center gap-2 text-lg text-primary">
                            <span className="font-medium text-gold">{i.qty}×</span> {i.name}
                          </li>
                        ))}
                      </ul>

                      {o.specialInstructions && (
                        <p className="mb-3 rounded-lg bg-base px-3 py-2 text-sm text-amber">
                          {o.specialInstructions}
                        </p>
                      )}

                      {action && (
                        <button
                          onClick={() => updateOrderStatus(o.id, action.next)}
                          className="btn-gold w-full py-2.5 text-sm"
                        >
                          {action.label}
                        </button>
                      )}
                    </article>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
