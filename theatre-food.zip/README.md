# Theatre Food Ordering System

Three interlinked apps that share a live data layer:

| App | Port | What it does |
|-----|------|--------------|
| Customer | 5173 | Order by **voice** or text + live order tracker |
| Admin | 5174 | Inventory, orders, theatre settings |
| Kitchen | 5175 | Auto-refreshing order board |

Plus two small background services: a WebSocket **sync relay** (port 5180) that
shares data across the three apps, and a **voice proxy** (port 5181) for the AI waiter.

## Prerequisites
- **Node.js 18+** (includes npm) — https://nodejs.org

## Setup (on any laptop)
```bash
git clone <your-repo-url>
cd theatre-food
npm install            # installs all three apps (npm workspaces)
```

### Optional: enable the AI voice waiter (free)
The app works out of the box with a built-in voice/text waiter. For the smarter
**Groq + Whisper + natural voice** waiter:
```bash
copy .env.example .env        # macOS/Linux: cp .env.example .env
```
Then open `.env` and add a **free** Groq key from https://console.groq.com/keys :
```
GROQ_API_KEY=gsk_your_key_here
```
(No billing required. Leaving it blank just uses the free browser voice instead.)

## Run
```bash
npm run dev
```
Then open **http://localhost:5173** in Chrome or Edge.
(Admin: http://localhost:5174 · Kitchen: http://localhost:5175)

Keep the terminal open while using the app. Allow the microphone when prompted to
order by voice.

## Notes
- `node_modules/` and `.env` are intentionally **not** in the repo — `npm install`
  recreates dependencies, and each person uses their own `.env` (keys stay private).
- Use a Chromium browser (Chrome/Edge) for the best voice support.
