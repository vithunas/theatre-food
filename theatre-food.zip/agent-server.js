/**
 * Realtime voice-waiter token proxy (OpenAI GA Realtime API).
 *
 * The browser cannot hold the real OpenAI API key, so this tiny server mints a
 * short-lived ephemeral client secret. The client then uses that secret to open
 * a WebRTC connection directly to the OpenAI Realtime API.
 *
 * Endpoints:
 *   GET  /health   -> { ok, hasKey, model }
 *   POST /session  -> { value, model, expires_at, raw }
 *     body (optional): { session: <partial GA session config> }
 *     The client sends the waiter instructions + tools + audio config here, and
 *     we merge in type/model and forward to OpenAI. Configuring the session at
 *     mint time means any schema error comes back immediately and clearly.
 *
 * GA endpoints (verified):
 *   POST https://api.openai.com/v1/realtime/client_secrets   (mint ephemeral token)
 *   POST https://api.openai.com/v1/realtime/calls?model=...   (WebRTC SDP, client-side)
 */
import "dotenv/config";
import http from "node:http";
import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";

const PORT = Number(process.env.AGENT_PORT || 5181);
const MODEL = process.env.OPENAI_REALTIME_MODEL || "gpt-realtime";
const VOICE = process.env.OPENAI_REALTIME_VOICE || "verse";

// Free "Groq brain + Edge-TTS voice" path.
const GROQ_MODEL = process.env.GROQ_MODEL || "llama-3.3-70b-versatile";
const GROQ_STT_MODEL = process.env.GROQ_STT_MODEL || "whisper-large-v3-turbo";
const TTS_VOICE = process.env.TTS_VOICE || "en-IN-NeerjaNeural";

const ALLOWED_ORIGINS = new Set([
  "http://localhost:5173",
  "http://127.0.0.1:5173",
  "http://localhost:5273",
  "http://127.0.0.1:5273",
]);

function cors(req, res) {
  const origin = req.headers.origin;
  res.setHeader("Access-Control-Allow-Origin", ALLOWED_ORIGINS.has(origin) ? origin : "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
}

function json(res, status, body) {
  res.writeHead(status, { "Content-Type": "application/json" });
  res.end(JSON.stringify(body));
}

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function readBody(req) {
  return new Promise((resolve) => {
    let data = "";
    req.on("data", (c) => (data += c));
    req.on("end", () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch {
        resolve({});
      }
    });
  });
}

/** Synthesize speech with Edge-TTS (free, no key); resolves to an MP3 Buffer. */
function synthesize(text, voice) {
  return new Promise(async (resolve, reject) => {
    try {
      const tts = new MsEdgeTTS();
      await tts.setMetadata(voice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);
      const result = tts.toStream(text);
      const stream = result.audioStream || result;
      const chunks = [];
      stream.on("data", (c) => chunks.push(c));
      stream.on("end", () => resolve(Buffer.concat(chunks)));
      stream.on("error", reject);
    } catch (err) {
      reject(err);
    }
  });
}

const server = http.createServer(async (req, res) => {
  cors(req, res);

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    return res.end();
  }

  if (req.method === "GET" && req.url === "/health") {
    return json(res, 200, {
      ok: true,
      hasKey: Boolean(process.env.OPENAI_API_KEY), // OpenAI Realtime
      groq: Boolean(process.env.GROQ_API_KEY), // free Groq brain
      tts: true, // Edge-TTS needs no key
      model: MODEL,
    });
  }

  // ---- Free path: Groq brain (chat + tool calling) ----
  if (req.method === "POST" && req.url === "/agent/chat") {
    const key = process.env.GROQ_API_KEY;
    if (!key) {
      return json(res, 503, { error: "GROQ_API_KEY is not set. Add it to theatre-food/.env and restart." });
    }
    const body = await readBody(req);
    const payload = {
      model: GROQ_MODEL,
      messages: body.messages || [],
      tools: body.tools,
      tool_choice: body.tools ? "auto" : undefined,
      temperature: 0.3,
    };
    // Groq occasionally emits a malformed tool call ("tool_use_failed"). It's
    // stochastic, so retry a couple of times, then degrade gracefully instead of
    // breaking the conversation.
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const r = await fetch("https://api.groq.com/openai/v1/chat/completions", {
          method: "POST",
          headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await r.json();
        if (r.ok) {
          return json(res, 200, { message: data.choices?.[0]?.message || { role: "assistant", content: "" } });
        }
        const code = data?.error?.code || "";
        const msg = data?.error?.message || "";
        if (code === "tool_use_failed" || /failed to call a function/i.test(msg)) {
          continue; // transient generation glitch — try again
        }
        return json(res, r.status, { error: msg || "Groq error", details: data });
      } catch {
        /* network blip — retry */
      }
    }
    return json(res, 200, {
      message: { role: "assistant", content: "Sorry, I didn't quite catch that — could you say it again?" },
      recovered: true,
    });
  }

  // ---- Free path: Groq Whisper transcription (customer voice note -> text) ----
  if (req.method === "POST" && req.url === "/agent/stt") {
    const key = process.env.GROQ_API_KEY;
    if (!key) {
      return json(res, 503, { error: "GROQ_API_KEY is not set. Add it to theatre-food/.env and restart." });
    }
    try {
      const buf = await readRawBody(req);
      if (!buf.length) return json(res, 400, { error: "No audio received." });
      const contentType = req.headers["content-type"] || "audio/webm";
      const form = new FormData();
      form.append("file", new Blob([buf], { type: contentType }), "voice.webm");
      form.append("model", GROQ_STT_MODEL);
      form.append("response_format", "json");
      const r = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", {
        method: "POST",
        headers: { Authorization: `Bearer ${key}` },
        body: form,
      });
      const data = await r.json();
      if (!r.ok) {
        return json(res, r.status, { error: data?.error?.message || "Transcription failed", details: data });
      }
      return json(res, 200, { text: (data.text || "").trim() });
    } catch (err) {
      return json(res, 502, { error: "STT failed", details: String(err) });
    }
  }

  // ---- Free path: Edge-TTS voice (no key) ----
  if (req.method === "POST" && req.url === "/agent/tts") {
    const body = await readBody(req);
    const text = (body.text || "").toString().slice(0, 1200);
    if (!text) return json(res, 400, { error: "No text" });
    try {
      const audio = await synthesize(text, body.voice || TTS_VOICE);
      res.writeHead(200, { "Content-Type": "audio/mpeg", "Content-Length": audio.length });
      return res.end(audio);
    } catch (err) {
      return json(res, 502, { error: "TTS failed", details: String(err) });
    }
  }

  if (req.method === "POST" && req.url === "/session") {
    const key = process.env.OPENAI_API_KEY;
    if (!key) {
      return json(res, 503, {
        error: "OPENAI_API_KEY is not set. Add it to theatre-food/.env and restart.",
      });
    }
    const body = await readBody(req);
    const clientSession = body?.session || {};
    const session = {
      type: "realtime",
      model: MODEL,
      audio: { output: { voice: VOICE } },
      ...clientSession,
    };
    try {
      const r = await fetch("https://api.openai.com/v1/realtime/client_secrets", {
        method: "POST",
        headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({ session }),
      });
      const data = await r.json();
      if (!r.ok) {
        return json(res, r.status, { error: data?.error?.message || "OpenAI session error", details: data });
      }
      return json(res, 200, { value: data.value, model: MODEL, expires_at: data.expires_at, raw: data });
    } catch (err) {
      return json(res, 502, { error: "Failed to reach OpenAI", details: String(err) });
    }
  }

  json(res, 404, { error: "Not found" });
});

server.listen(PORT, () => {
  const openai = process.env.OPENAI_API_KEY ? "OpenAI✓" : "OpenAI✗";
  const groq = process.env.GROQ_API_KEY ? "Groq✓" : "Groq✗";
  console.log(`[agent] voice proxy on http://localhost:${PORT} (${openai} ${groq} Edge-TTS✓, voice ${TTS_VOICE})`);
});
