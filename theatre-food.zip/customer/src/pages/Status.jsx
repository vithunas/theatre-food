import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, Star, Timer, RotateCcw } from "lucide-react";
import { getOrders, saveFeedback } from "@shared/data.js";
import { useLive } from "../lib/useLive.js";
import { inr } from "../lib/format.js";
import Stepper from "../components/Stepper.jsx";
import Confetti from "../components/Confetti.jsx";

const TOTAL_SECONDS = 20 * 60;

function fmt(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export default function Status() {
  const { id } = useParams();
  const navigate = useNavigate();
  const orders = useLive(() => getOrders(), { pollMs: 5000 });
  const order = useMemo(() => orders.find((o) => o.id === id), [orders, id]);

  const [, setTick] = useState(0);
  const [showSummary, setShowSummary] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [confetti, setConfetti] = useState(false);

  // 1s ticker for the countdown.
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const delivered = order?.status === "delivered";
  const submitted = Boolean(order?.feedback);

  // Celebrate + prompt for feedback once delivered.
  useEffect(() => {
    if (delivered) {
      setConfetti(true);
      const t = setTimeout(() => setConfetti(false), 2200);
      if (!submitted) setShowFeedback(true);
      return () => clearTimeout(t);
    }
  }, [delivered, submitted]);

  if (!order) {
    return (
      <main className="flex flex-1 items-center justify-center p-6 text-center text-muted">
        We couldn’t find that order.
      </main>
    );
  }

  const remaining = delivered
    ? 0
    : Math.max(0, TOTAL_SECONDS - Math.floor((Date.now() - order.placedAt) / 1000));

  const submitFeedback = () => {
    if (rating === 0) return;
    saveFeedback(order.id, { rating, comment: comment.trim() });
    setShowFeedback(false);
  };

  return (
    <main className="mx-auto w-full max-w-xl flex-1 px-4 py-6 sm:px-6">
      {confetti && <Confetti />}

      <div className="text-center">
        <h1 className="font-heading text-3xl text-primary">
          {delivered ? "Enjoy your meal!" : "Order confirmed!"}
        </h1>
        <p className="mt-1 text-sm text-muted">
          {order.id} · Seat {order.seatNumber}
        </p>
        {!delivered && (
          <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-hairline bg-surface px-4 py-2 text-sm">
            <Timer size={15} className="text-gold" />
            <span className="text-muted">Estimated</span>
            <span className="font-medium text-primary">{fmt(remaining)}</span>
          </div>
        )}
      </div>

      <div className="mt-8 rounded-2xl border border-hairline bg-surface p-5">
        <Stepper status={order.status} />
      </div>

      {/* Collapsible summary */}
      <div className="mt-4 overflow-hidden rounded-2xl border border-hairline bg-surface">
        <button
          onClick={() => setShowSummary((v) => !v)}
          className="flex w-full items-center justify-between px-5 py-4 text-sm text-primary transition-colors hover:bg-elevated"
        >
          <span>Order summary</span>
          <ChevronDown size={18} className={`transition-transform ${showSummary ? "rotate-180" : ""}`} />
        </button>
        <AnimatePresence initial={false}>
          {showSummary && (
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: "auto" }}
              exit={{ height: 0 }}
              className="overflow-hidden"
            >
              <div className="space-y-2 border-t border-hairline px-5 py-4 text-sm">
                {order.items.map((i) => (
                  <div key={i.id} className="flex justify-between text-muted">
                    <span>
                      {i.qty} × {i.name}
                    </span>
                    <span>{inr(i.price * i.qty)}</span>
                  </div>
                ))}
                {order.specialInstructions && (
                  <p className="pt-1 text-xs text-muted">Note: {order.specialInstructions}</p>
                )}
                <div className="flex justify-between border-t border-hairline pt-2 font-medium text-primary">
                  <span>Total</span>
                  <span>{inr(order.totalAmount)}</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Feedback */}
      <AnimatePresence>
        {(showFeedback || (delivered && !submitted)) && !submitted && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-4 rounded-2xl border border-hairline bg-surface p-5 text-center"
          >
            <p className="font-heading text-lg text-primary">How was your meal?</p>
            <div className="mt-3 flex justify-center gap-1.5">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  onClick={() => setRating(n)}
                  className="text-muted transition-transform hover:scale-110 active:scale-95"
                  aria-label={`${n} star`}
                >
                  <Star
                    size={28}
                    style={{
                      fill: n <= rating ? "var(--gold)" : "transparent",
                      color: n <= rating ? "var(--gold)" : "var(--text-muted)",
                    }}
                  />
                </button>
              ))}
            </div>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={2}
              placeholder="Tell us more (optional)"
              className="mt-3 w-full resize-none rounded-xl border border-hairline bg-base px-3 py-2 text-sm text-primary outline-none transition-colors placeholder:text-muted/60 focus:border-gold"
            />
            <button onClick={submitFeedback} disabled={rating === 0} className="btn-gold mt-3 w-full py-3">
              Submit rating
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {submitted && (
        <p className="mt-4 rounded-2xl border border-hairline bg-surface p-4 text-center text-sm text-success">
          Thanks for rating {order.feedback.rating}/5!
        </p>
      )}

      {/* Actions */}
      <div className="mt-4 flex gap-3">
        <button onClick={() => navigate("/order")} className="btn-ghost flex flex-1 items-center justify-center gap-2 py-3">
          <RotateCcw size={16} /> Order more
        </button>
        {!submitted && (
          <button onClick={() => setShowFeedback((v) => !v)} className="btn-gold flex flex-1 items-center justify-center gap-2 py-3">
            <Star size={16} /> Rate your order
          </button>
        )}
      </div>
    </main>
  );
}
