import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { getMenu, saveOrder, updateStock } from "@shared/data.js";
import { GST_RATE } from "@shared/constants.js";
import { useLive } from "../lib/useLive.js";
import { useCart } from "../lib/CartContext.jsx";
import VoicePanel from "../components/VoicePanel.jsx";
import MenuGrid from "../components/MenuGrid.jsx";
import Cart from "../components/Cart.jsx";
import PlaceOrderOverlay from "../components/PlaceOrderOverlay.jsx";

export default function Order() {
  const navigate = useNavigate();
  const menu = useLive(() => getMenu());
  const { items, add, clear, subtotal } = useCart();
  const seat = sessionStorage.getItem("tfo_seat");

  const [loading, setLoading] = useState(true);
  const [instructions, setInstructions] = useState("");
  const [placing, setPlacing] = useState(false);
  const [overlay, setOverlay] = useState(false);

  // Simulate a fetch: show skeletons briefly before the menu appears.
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!seat) navigate("/", { replace: true });
  }, [seat, navigate]);

  const total = useMemo(() => subtotal + Math.round(subtotal * GST_RATE), [subtotal]);

  const place = () => {
    if (items.length === 0 || placing) return;
    setPlacing(true);
    setTimeout(() => {
      const id = "ORD-" + Date.now();
      const now = Date.now();
      saveOrder({
        id,
        seatNumber: seat,
        items: items.map((i) => ({ id: i.id, name: i.name, qty: i.qty, price: i.price })),
        status: "placed",
        placedAt: now,
        updatedAt: now,
        totalAmount: total,
        specialInstructions: instructions.trim(),
        feedback: null,
      });
      items.forEach((i) => updateStock(i.id, -i.qty));
      clear();
      setPlacing(false);
      setOverlay(true);
      setTimeout(() => navigate(`/status/${id}`), 1200);
    }, 500);
  };

  return (
    <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-5 sm:px-6">
      <div className="flex flex-col gap-4 lg:flex-row">
        <section className="rounded-2xl border border-hairline bg-surface p-4 lg:w-[30%]">
          <VoicePanel
            menu={menu}
            seat={seat}
            setInstructions={setInstructions}
            onPlaceOrder={place}
          />
        </section>

        <section className="rounded-2xl border border-hairline bg-surface p-4 lg:w-[45%]">
          <MenuGrid menu={menu} loading={loading} onAdd={add} />
        </section>

        <section className="rounded-2xl border border-hairline bg-surface p-4 lg:w-[25%]">
          <Cart
            seat={seat}
            onPlace={place}
            placing={placing}
            instructions={instructions}
            setInstructions={setInstructions}
          />
        </section>
      </div>

      <AnimatePresence>{overlay && <PlaceOrderOverlay />}</AnimatePresence>
    </main>
  );
}
