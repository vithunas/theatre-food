import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronDown, RotateCcw } from "lucide-react";
import { getOrders } from "@shared/data.js";
import { STATUS_LABELS } from "@shared/constants.js";
import { useLive } from "../lib/useLive.js";
import { inr } from "../lib/format.js";
import { useCart } from "../lib/CartContext.jsx";

const FILTERS = ["All", "Active", "Completed"];

function StatusBadge({ status }) {
  const color =
    status === "delivered" ? "var(--success)" : status === "placed" ? "var(--text-muted)" : "var(--gold)";
  return (
    <span
      className="rounded-full border px-2.5 py-0.5 text-xs"
      style={{ color, borderColor: "var(--border)" }}
    >
      {STATUS_LABELS[status] || status}
    </span>
  );
}

function PopcornEmpty() {
  return (
    <div className="flex flex-col items-center py-16 text-center">
      <div className="relative h-24 w-20">
        {/* popcorn pieces */}
        <div className="absolute left-2 top-0 h-5 w-5 rounded-full bg-gold" />
        <div className="absolute left-8 -top-1 h-6 w-6 rounded-full bg-primary/80" />
        <div className="absolute right-1 top-1 h-5 w-5 rounded-full bg-gold" />
        {/* cup */}
        <div
          className="absolute bottom-0 left-1/2 h-16 w-16 -translate-x-1/2 overflow-hidden rounded-b-md"
          style={{
            background:
              "repeating-linear-gradient(90deg, var(--danger) 0 8px, var(--text-primary) 8px 16px)",
            clipPath: "polygon(12% 0, 88% 0, 78% 100%, 22% 100%)",
          }}
        />
      </div>
      <p className="mt-6 text-primary">No orders yet.</p>
      <p className="text-sm text-muted">Find your seat and dig in.</p>
    </div>
  );
}

export default function History() {
  const orders = useLive(() => getOrders());
  const [filter, setFilter] = useState("All");
  const [open, setOpen] = useState(null);
  const { replace } = useCart();
  const navigate = useNavigate();

  const list = useMemo(() => {
    const sorted = [...orders].sort((a, b) => b.placedAt - a.placedAt);
    if (filter === "Active") return sorted.filter((o) => o.status !== "delivered");
    if (filter === "Completed") return sorted.filter((o) => o.status === "delivered");
    return sorted;
  }, [orders, filter]);

  const orderAgain = (order) => {
    replace(order.items);
    navigate("/order");
  };

  return (
    <main className="mx-auto w-full max-w-2xl flex-1 px-4 py-6 sm:px-6">
      <h1 className="font-heading text-3xl text-primary">Your orders</h1>

      <div className="mt-4 flex gap-2">
        {FILTERS.map((f) => (
          <button key={f} data-active={filter === f} onClick={() => setFilter(f)} className="pill px-3.5 py-1.5 text-sm">
            {f}
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <PopcornEmpty />
      ) : (
        <ul className="mt-5 flex flex-col gap-3">
          {list.map((o) => {
            const count = o.items.reduce((s, i) => s + i.qty, 0);
            const expanded = open === o.id;
            return (
              <li key={o.id} className="overflow-hidden rounded-2xl border border-hairline bg-surface">
                <button
                  onClick={() => setOpen(expanded ? null : o.id)}
                  className="flex w-full items-center justify-between gap-3 px-4 py-4 text-left transition-colors hover:bg-elevated"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-primary">{o.id}</span>
                      <StatusBadge status={o.status} />
                    </div>
                    <p className="mt-0.5 text-xs text-muted">
                      {new Date(o.placedAt).toLocaleString("en-IN", {
                        day: "numeric",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}{" "}
                      · {count} item{count !== 1 ? "s" : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-medium text-primary">{inr(o.totalAmount)}</span>
                    <ChevronDown size={18} className={`text-muted transition-transform ${expanded ? "rotate-180" : ""}`} />
                  </div>
                </button>
                {expanded && (
                  <div className="border-t border-hairline px-4 py-4">
                    <ul className="space-y-1.5 text-sm">
                      {o.items.map((i) => (
                        <li key={i.id} className="flex justify-between text-muted">
                          <span>
                            {i.qty} × {i.name}
                          </span>
                          <span>{inr(i.price * i.qty)}</span>
                        </li>
                      ))}
                    </ul>
                    <button onClick={() => orderAgain(o)} className="btn-gold mt-4 flex items-center gap-2 px-4 py-2 text-sm">
                      <RotateCcw size={15} /> Order again
                    </button>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </main>
  );
}
