import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Armchair, Clapperboard, Lock } from "lucide-react";
import { getSettings } from "@shared/data.js";
import { useLive } from "../lib/useLive.js";

export default function CheckIn() {
  const settings = useLive(() => getSettings());
  const [seat, setSeat] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  // Keep input as one row letter followed by up to two digits, e.g. "A", "A1", "A12".
  const onSeatChange = (e) => {
    const raw = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "");
    let out = "";
    for (const ch of raw) {
      if (out.length === 0) {
        if (/[A-Z]/.test(ch)) out += ch; // first char must be the row letter
      } else if (out.length < 3 && /\d/.test(ch)) {
        out += ch; // then up to two seat-number digits
      }
    }
    setSeat(out);
    if (error) setError("");
  };

  const submit = (e) => {
    e.preventDefault();
    const match = seat.match(/^([A-Z])(\d{1,2})$/);
    if (!match) {
      setError("Enter a seat like A12 — a row letter then a number.");
      return;
    }
    const num = parseInt(match[2], 10);
    if (num < 1 || num > 60) {
      setError("Seat number must be between 1 and 60.");
      return;
    }
    const value = `${match[1]}${String(num).padStart(2, "0")}`; // e.g. A01–A60
    sessionStorage.setItem("tfo_seat", value);
    navigate("/order");
  };

  return (
    <main className="flex h-full flex-1 flex-col items-center justify-center overflow-hidden px-6 text-center">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-sm"
      >
        <div className="mb-6 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-elevated text-gold">
          <Clapperboard size={26} />
        </div>
        <h1 className="font-heading text-4xl text-primary">{settings.theatreName}</h1>
        <p className="mt-2 text-muted">In-seat dining, delivered while you watch.</p>

        {settings.orderingEnabled ? (
          <form onSubmit={submit} className="mt-10">
            <label className="mb-2 block text-left text-sm text-muted">Your seat number</label>
            <div className="relative">
              <Armchair size={20} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-gold" />
              <input
                autoFocus
                value={seat}
                onChange={onSeatChange}
                inputMode="text"
                maxLength={3}
                placeholder="e.g. A12"
                aria-invalid={Boolean(error)}
                className="w-full rounded-2xl border border-hairline bg-surface py-5 pl-12 pr-4 text-center text-2xl tracking-widest text-primary outline-none transition-colors placeholder:text-muted/60 focus:border-gold"
              />
            </div>
            {error ? (
              <p className="mt-2 text-left text-sm text-danger">{error}</p>
            ) : (
              <p className="mt-2 text-left text-xs text-muted">Row letter A–Z, seat number 1–60 (e.g. A01–A60).</p>
            )}
            <button type="submit" disabled={!seat.trim()} className="btn-gold mt-5 w-full py-4 text-base">
              Start ordering
            </button>
          </form>
        ) : (
          <div className="mt-10 flex flex-col items-center gap-3 rounded-2xl border border-hairline bg-surface p-8">
            <Lock size={22} className="text-danger" />
            <p className="text-primary">Ordering is paused.</p>
            <p className="text-sm text-muted">Please check with staff.</p>
          </div>
        )}
      </motion.div>
    </main>
  );
}
