import { Minus, Plus, Trash2, Armchair } from "lucide-react";
import { GST_RATE } from "@shared/constants.js";
import { inr } from "../lib/format.js";
import { useCart } from "../lib/CartContext.jsx";

export default function Cart({ seat, onPlace, placing, instructions, setInstructions }) {
  const { items, setQty, remove, subtotal } = useCart();
  const gst = Math.round(subtotal * GST_RATE);
  const total = subtotal + gst;

  return (
    <div className="flex h-full flex-col">
      <div className="mb-3 flex items-center gap-1.5 text-sm text-muted">
        <Armchair size={15} className="text-gold" /> Seat {seat || "—"}
      </div>

      <div className="flex-1 overflow-y-auto pr-1">
        {items.length === 0 ? (
          <p className="mt-8 text-center text-sm text-muted">
            Your cart is empty. Add items from the menu or use voice.
          </p>
        ) : (
          <ul className="flex flex-col gap-2">
            {items.map((i) => (
              <li key={i.id} className="rounded-xl border border-hairline bg-base/40 p-3">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm text-primary">{i.name}</p>
                  <button
                    onClick={() => remove(i.id)}
                    className="text-muted transition-colors hover:text-danger"
                    aria-label={`Remove ${i.name}`}
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setQty(i.id, i.qty - 1)}
                      className="btn-ghost grid h-7 w-7 place-items-center p-0"
                      aria-label="Decrease"
                    >
                      <Minus size={13} />
                    </button>
                    <span className="w-5 text-center text-sm text-primary">{i.qty}</span>
                    <button
                      onClick={() => setQty(i.id, i.qty + 1)}
                      className="btn-ghost grid h-7 w-7 place-items-center p-0"
                      aria-label="Increase"
                    >
                      <Plus size={13} />
                    </button>
                  </div>
                  <span className="text-sm text-muted">{inr(i.price * i.qty)}</span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <textarea
        value={instructions}
        onChange={(e) => setInstructions(e.target.value)}
        placeholder="Special instructions (e.g. less ice, extra napkins)"
        rows={2}
        className="mt-3 w-full resize-none rounded-xl border border-hairline bg-surface px-3 py-2 text-sm text-primary outline-none transition-colors placeholder:text-muted/60 focus:border-gold"
      />

      <div className="mt-3 space-y-1 border-t border-hairline pt-3 text-sm">
        <Row label="Subtotal" value={inr(subtotal)} />
        <Row label="GST (5%)" value={inr(gst)} />
        <Row label="Total" value={inr(total)} strong />
      </div>

      <button
        onClick={onPlace}
        disabled={items.length === 0 || placing}
        className="btn-gold mt-3 flex w-full items-center justify-center gap-2 py-3.5 text-base"
      >
        {placing ? <span className="h-5 w-5 animate-spin rounded-full border-2 border-base border-t-transparent" /> : "Place order"}
      </button>
    </div>
  );
}

function Row({ label, value, strong }) {
  return (
    <div className={`flex justify-between ${strong ? "text-primary" : "text-muted"}`}>
      <span className={strong ? "font-medium" : ""}>{label}</span>
      <span className={strong ? "font-medium" : ""}>{value}</span>
    </div>
  );
}
