import { Check } from "lucide-react";
import { STATUS_FLOW, STATUS_LABELS } from "@shared/constants.js";

export default function Stepper({ status }) {
  const current = Math.max(0, STATUS_FLOW.indexOf(status));
  // "delivered" is terminal — once reached, the final step is complete, not "in progress".
  const atFinal = current === STATUS_FLOW.length - 1;

  return (
    <ol className="relative flex flex-col gap-0">
      {STATUS_FLOW.map((s, i) => {
        const last = i === STATUS_FLOW.length - 1;
        const done = i < current || (atFinal && i === current);
        const active = i === current && !atFinal;
        return (
          <li key={s} className="flex gap-4">
            <div className="flex flex-col items-center">
              <span
                className={`grid h-9 w-9 place-items-center rounded-full border transition-colors ${
                  done
                    ? "border-gold bg-gold text-base"
                    : active
                      ? "step-pulse border-gold bg-gold/15 text-gold"
                      : "border-hairline bg-surface text-muted"
                }`}
              >
                {done ? <Check size={16} /> : <span className="text-sm">{i + 1}</span>}
              </span>
              {!last && (
                <span className={`my-1 h-8 w-0.5 ${i < current ? "bg-gold" : "bg-hairline"}`} />
              )}
            </div>
            <div className={`pt-1.5 ${active ? "text-primary" : done ? "text-primary/80" : "text-muted"}`}>
              <p className={active ? "font-medium" : ""}>{STATUS_LABELS[s]}</p>
              {active && <p className="text-xs text-gold">In progress</p>}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
