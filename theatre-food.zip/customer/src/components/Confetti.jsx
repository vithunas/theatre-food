const COLORS = ["var(--gold)", "var(--success)", "var(--amber)", "var(--danger)", "var(--text-primary)"];

/** Pure-CSS confetti burst: colored squares flying upward. */
export default function Confetti({ pieces = 44 }) {
  return (
    <div className="pointer-events-none fixed inset-0 z-40 overflow-hidden">
      {Array.from({ length: pieces }).map((_, i) => (
        <span
          key={i}
          className="confetti-piece"
          style={{
            left: `${Math.random() * 100}%`,
            background: COLORS[i % COLORS.length],
            animationDelay: `${Math.random() * 0.5}s`,
            borderRadius: i % 2 ? "2px" : "999px",
          }}
        />
      ))}
    </div>
  );
}
