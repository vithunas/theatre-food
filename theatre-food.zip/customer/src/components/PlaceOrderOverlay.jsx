import { motion } from "framer-motion";

/** Full-screen gold overlay that slides up, then draws a checkmark. */
export default function PlaceOrderOverlay() {
  return (
    <motion.div
      initial={{ y: "100%" }}
      animate={{ y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center"
      style={{ background: "var(--gold)" }}
    >
      <svg width="120" height="120" viewBox="0 0 60 60" fill="none">
        <circle
          className="check-circle"
          cx="30"
          cy="30"
          r="26"
          stroke="var(--bg-base)"
          strokeWidth="3"
        />
        <path
          className="check-tick"
          d="M19 31l7 7 15-16"
          stroke="var(--bg-base)"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="mt-6 font-heading text-2xl"
        style={{ color: "var(--bg-base)" }}
      >
        Order placed
      </motion.p>
    </motion.div>
  );
}
