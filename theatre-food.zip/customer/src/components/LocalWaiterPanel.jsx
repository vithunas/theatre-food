import { useEffect, useRef, useState } from "react";
import { Mic, PhoneOff, Keyboard, Send, AlertCircle } from "lucide-react";
import { useBrowserVoice } from "../lib/useBrowserVoice.js";
import { createLocalWaiter } from "../lib/localWaiter.js";

/**
 * No-key mode: a hands-free voice conversation. The waiter greets, listens,
 * replies aloud, then listens again — looping until the order is placed. Typing
 * is an optional fallback, hidden behind a toggle.
 */
export default function LocalWaiterPanel({ menu, actions }) {
  const { sttSupported, ttsSupported, listening, voiceError, ensureMic, listen, stopListening, speak } =
    useBrowserVoice();

  const waiterRef = useRef(null);
  if (!waiterRef.current) waiterRef.current = createLocalWaiter(menu);

  const [transcript, setTranscript] = useState([]);
  const [active, setActive] = useState(false); // voice conversation running
  const [showText, setShowText] = useState(!sttSupported); // typing fallback visible
  const [draft, setDraft] = useState("");
  const [heard, setHeard] = useState(""); // live partial transcript

  const activeRef = useRef(false);
  activeRef.current = active;
  const greetedRef = useRef(false);
  const logRef = useRef(null);

  const applyOps = (ops) => {
    for (const op of ops) {
      if (op.type === "add") actions.addItems([{ name: op.name, quantity: op.quantity }]);
      else if (op.type === "remove") actions.removeItem(op.name);
      else if (op.type === "setQty") actions.setQuantity(op.name, op.quantity);
      else if (op.type === "note") actions.setNote(op.text);
      else if (op.type === "place") actions.place();
    }
  };

  // Re-arm the mic for the next customer turn.
  const armListen = () => {
    if (!activeRef.current || !sttSupported) return;
    setHeard("");
    listen(
      handleUtterance,
      (gotResult) => {
        setHeard("");
        // If the customer stayed silent, keep listening (hands-free), with a
        // small gap so a persistent error can't spin a tight loop.
        if (!gotResult && activeRef.current) setTimeout(armListen, 500);
      },
      (interim) => setHeard(interim)
    );
  };

  // Process one turn of the conversation, then speak and loop.
  const handleTurn = (text) => {
    stopListening();
    setTranscript((t) => [...t, { role: "you", text }]);
    const { reply, ops } = waiterRef.current.handle(text, actions.items);
    applyOps(ops);
    const placed = ops.some((o) => o.type === "place");
    setTranscript((t) => [...t, { role: "waiter", text: reply }]);
    speak(reply, () => {
      if (placed) {
        setActive(false); // order placed; the page will navigate away
      } else if (activeRef.current) {
        armListen();
      }
    });
  };

  function handleUtterance(text) {
    handleTurn(text);
  }

  const greetingText = () => waiterRef.current.greeting();

  // Greet (as text) once on mount.
  useEffect(() => {
    if (greetedRef.current) return;
    greetedRef.current = true;
    setTranscript([{ role: "waiter", text: greetingText() }]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [transcript]);

  const startVoice = async () => {
    // Confirm mic access first so failures are explicit (the usual "no response" cause).
    const ok = await ensureMic();
    if (!ok) return;
    setActive(true);
    activeRef.current = true;
    // Speak the greeting on the first start (needs the user gesture for audio).
    const greeting = transcript[0]?.text || greetingText();
    speak(greeting, () => {
      if (activeRef.current) armListen();
    });
  };

  const endVoice = () => {
    setActive(false);
    activeRef.current = false;
    stopListening();
    if (ttsSupported) window.speechSynthesis.cancel();
  };

  const submitText = (e) => {
    e.preventDefault();
    const text = draft.trim();
    if (!text) return;
    setDraft("");
    handleTurn(text);
  };

  const statusLabel = !sttSupported
    ? "Voice isn’t supported here — type below"
    : active
      ? listening
        ? "Listening — go ahead"
        : "Waiter is speaking…"
      : "Tap to start the voice chat";

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-col items-center gap-3 py-3">
        {sttSupported && (
          <>
            <div className="relative h-24 w-24">
              <div
                className="mic-rings absolute inset-0"
                data-state={active ? (listening ? "listening" : "processing") : "idle"}
              />
              <button
                onClick={active ? endVoice : startVoice}
                aria-label={active ? "End voice chat" : "Start voice chat"}
                className={`relative grid h-24 w-24 place-items-center rounded-full border text-gold transition-transform active:scale-95 ${
                  active ? "border-gold bg-elevated" : "mic-idle border-hairline bg-elevated hover:border-gold"
                }`}
              >
                {active ? <PhoneOff size={28} className="text-danger" /> : <Mic size={30} />}
              </button>
            </div>
          </>
        )}
        <p className="text-center text-sm font-medium text-primary">{statusLabel}</p>
        {active && listening && heard && (
          <p className="max-w-full truncate px-2 text-center text-xs italic text-muted">“{heard}”</p>
        )}
        {active && (
          <button onClick={endVoice} className="btn-ghost px-4 py-1.5 text-sm">
            End voice chat
          </button>
        )}
      </div>

      {voiceError && (
        <div className="mb-2 flex items-start gap-2 rounded-xl border border-hairline bg-base/40 px-3 py-2 text-sm text-danger">
          <AlertCircle size={15} className="mt-0.5 shrink-0" />
          <span>{voiceError}</span>
        </div>
      )}

      <div ref={logRef} className="flex-1 overflow-y-auto rounded-xl border border-hairline bg-base/40 p-3">
        <ul className="space-y-2">
          {transcript.map((line, i) => (
            <li key={i} className={line.role === "you" ? "text-right" : "text-left"}>
              <span className="mb-0.5 block text-[11px] uppercase tracking-wide text-muted">
                {line.role === "you" ? "You" : "Waiter"}
              </span>
              <span
                className={`inline-block rounded-xl px-3 py-1.5 text-sm ${
                  line.role === "you" ? "bg-gold text-base" : "bg-elevated text-primary"
                }`}
              >
                {line.text}
              </span>
            </li>
          ))}
        </ul>
      </div>

      {/* Optional typing fallback */}
      {sttSupported && (
        <button
          onClick={() => setShowText((v) => !v)}
          className="mt-2 flex items-center justify-center gap-1.5 text-xs text-muted transition-colors hover:text-gold"
        >
          <Keyboard size={13} /> {showText ? "Hide typing" : "Type instead"}
        </button>
      )}
      {showText && (
        <form onSubmit={submitText} className="mt-2 flex gap-2">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Type your order…"
            className="flex-1 rounded-xl border border-hairline bg-surface px-3 py-2 text-sm text-primary outline-none transition-colors placeholder:text-muted/60 focus:border-gold"
          />
          <button type="submit" className="btn-gold flex items-center gap-1 px-3 text-sm">
            <Send size={15} />
          </button>
        </form>
      )}
      {!ttsSupported && (
        <p className="mt-2 text-center text-[11px] text-muted">Spoken replies aren’t supported here, but the waiter still replies in text.</p>
      )}
    </div>
  );
}
