import { useEffect, useState } from "react";
import { Sparkles } from "lucide-react";
import { useOrderActions } from "../lib/orderActions.js";
import RealtimeWaiterPanel from "./RealtimeWaiterPanel.jsx";
import GroqWaiterPanel from "./GroqWaiterPanel.jsx";
import LocalWaiterPanel from "./LocalWaiterPanel.jsx";

const PROXY = "http://localhost:5181";

const BADGE = { groq: "Free AI", ai: "Live AI", local: "Quick voice" };

/**
 * Voice waiter. Picks the mode automatically (preferring the free Groq brain):
 *  - "groq":  Groq brain + Edge-TTS voice (free key, natural voice).
 *  - "ai":    OpenAI Realtime speech-to-speech (paid key).
 *  - "local": zero-setup browser voice + text waiter (no key at all).
 */
export default function VoicePanel({ menu, seat, setInstructions, onPlaceOrder }) {
  const actions = useOrderActions({ menu, seat, setInstructions, onPlaceOrder });
  const [mode, setMode] = useState("detecting"); // detecting | groq | ai | local

  useEffect(() => {
    let alive = true;
    fetch(`${PROXY}/health`)
      .then((r) => r.json())
      .then((d) => {
        if (!alive) return;
        if (d?.groq) setMode("groq");
        else if (d?.hasKey) setMode("ai");
        else setMode("local");
      })
      .catch(() => alive && setMode("local"));
    return () => {
      alive = false;
    };
  }, []);

  return (
    <div className="flex h-full flex-col">
      <div className="mb-1 flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-muted">
          <Sparkles size={15} className="text-gold" /> Voice waiter
        </div>
        {mode !== "detecting" && (
          <span className="rounded-full border border-hairline px-2 py-0.5 text-[10px] uppercase tracking-wide text-muted">
            {BADGE[mode]}
          </span>
        )}
      </div>

      {mode === "detecting" && (
        <div className="flex flex-1 items-center justify-center text-sm text-muted">Starting the waiter…</div>
      )}
      {mode === "groq" && <GroqWaiterPanel actions={actions} />}
      {mode === "ai" && <RealtimeWaiterPanel actions={actions} onFallback={() => setMode("local")} />}
      {mode === "local" && <LocalWaiterPanel menu={menu} actions={actions} />}
    </div>
  );
}
