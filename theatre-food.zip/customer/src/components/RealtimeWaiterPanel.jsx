import { useEffect, useRef, useState } from "react";
import { Mic, PhoneOff, AlertCircle, Keyboard, Send } from "lucide-react";
import { useRealtimeWaiter } from "../lib/useRealtimeWaiter.js";

const STATUS_LABEL = {
  idle: "Tap to talk to the waiter",
  connecting: "Connecting…",
  listening: "Listening — go ahead",
  speaking: "Waiter is speaking…",
  ended: "Conversation ended — tap to start again",
  error: "Couldn't start the live waiter",
};

/** AI mode: OpenAI Realtime speech-to-speech waiter. */
export default function RealtimeWaiterPanel({ actions, onFallback }) {
  const { status, transcript, error, start, stop, sendText } = useRealtimeWaiter({
    buildContext: actions.buildContext,
    onToolCall: actions.toolCall,
  });

  const [showText, setShowText] = useState(false);
  const [draft, setDraft] = useState("");
  const logRef = useRef(null);
  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [transcript]);

  const active = status === "connecting" || status === "listening" || status === "speaking";
  const ringState =
    status === "connecting" ? "processing" : status === "listening" || status === "speaking" ? "listening" : "idle";

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-col items-center gap-4 py-4">
        <div className="relative h-28 w-28">
          <div className="mic-rings absolute inset-0" data-state={ringState} />
          <button
            onClick={active ? stop : start}
            aria-label={active ? "End conversation" : "Talk to the waiter"}
            className={`relative grid h-28 w-28 place-items-center rounded-full border text-gold transition-transform active:scale-95 ${
              active ? "border-gold bg-elevated" : "mic-idle border-hairline bg-elevated hover:border-gold"
            }`}
          >
            {active ? <PhoneOff size={32} className="text-danger" /> : <Mic size={34} />}
          </button>
        </div>
        <p className="text-sm font-medium text-primary">{STATUS_LABEL[status]}</p>
        {active && (
          <button onClick={stop} className="btn-ghost px-4 py-2 text-sm">
            End conversation
          </button>
        )}
      </div>

      {error && (
        <div className="mb-3 rounded-xl border border-hairline bg-base/40 px-3 py-2 text-sm">
          <div className="flex items-start gap-2 text-danger">
            <AlertCircle size={15} className="mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={onFallback} className="btn-ghost mt-2 w-full py-1.5 text-xs">
            Use the quick voice waiter instead
          </button>
        </div>
      )}

      <div ref={logRef} className="mt-auto max-h-56 flex-1 overflow-y-auto rounded-xl border border-hairline bg-base/40 p-3">
        {transcript.length === 0 ? (
          <p className="text-center text-sm text-muted">
            Tap the mic and just talk — “I’d like a salted popcorn and a cold coffee.”
          </p>
        ) : (
          <ul className="space-y-2">
            {transcript.map((line, i) => (
              <li key={i} className={line.role === "you" ? "text-right" : "text-left"}>
                <span className="mb-0.5 block text-[11px] uppercase tracking-wide text-muted">
                  {line.role === "you" ? "You" : "Waiter"}
                </span>
                <span
                  className={`inline-block rounded-xl px-3 py-1.5 text-sm ${
                    line.role === "you" ? "bg-gold text-base" : "bg-elevated text-primary"
                  }`}
                >
                  {line.text}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Optional typing — voice stays the primary way to order. */}
      {active && (
        <>
          <button
            onClick={() => setShowText((v) => !v)}
            className="mt-2 flex items-center justify-center gap-1.5 text-xs text-muted transition-colors hover:text-gold"
          >
            <Keyboard size={13} /> {showText ? "Hide typing" : "Type instead"}
          </button>
          {showText && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const text = draft.trim();
                if (!text) return;
                setDraft("");
                sendText(text);
              }}
              className="mt-2 flex gap-2"
            >
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder="Type your order…"
                className="flex-1 rounded-xl border border-hairline bg-surface px-3 py-2 text-sm text-primary outline-none transition-colors placeholder:text-muted/60 focus:border-gold"
              />
              <button type="submit" className="btn-gold flex items-center gap-1 px-3 text-sm">
                <Send size={15} />
              </button>
            </form>
          )}
        </>
      )}
    </div>
  );
}
