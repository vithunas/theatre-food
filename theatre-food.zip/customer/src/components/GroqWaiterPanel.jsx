import { useEffect, useRef, useState } from "react";
import { Mic, Square, Keyboard, Send, AlertCircle, Loader } from "lucide-react";
import { useGroqWaiter } from "../lib/useGroqWaiter.js";

const STATUS_LABEL = {
  idle: "Tap to talk to the waiter",
  recording: "Recording — tap to send",
  thinking: "Got it, thinking…",
  speaking: "Waiter is speaking… (tap to interrupt)",
  ended: "Tap to talk again",
  error: "Something went wrong",
};

/** Free mode: record voice (Whisper STT) → Groq brain → Edge-TTS voice. */
export default function GroqWaiterPanel({ actions }) {
  const { status, transcript, error, toggle, stop, sendText, recordSupported } = useGroqWaiter({
    buildContext: actions.buildContext,
    onToolCall: actions.toolCall,
  });

  const [showText, setShowText] = useState(!recordSupported);
  const [draft, setDraft] = useState("");
  const logRef = useRef(null);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [transcript]);

  const inConversation = status === "recording" || status === "thinking" || status === "speaking";
  const ringState =
    status === "recording" ? "listening" : status === "thinking" || status === "speaking" ? "processing" : "idle";

  const submitText = (e) => {
    e.preventDefault();
    const text = draft.trim();
    if (!text) return;
    setDraft("");
    sendText(text);
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-col items-center gap-3 py-3">
        {recordSupported && (
          <div className="relative h-24 w-24">
            <div className="mic-rings absolute inset-0" data-state={ringState} />
            <button
              onClick={toggle}
              disabled={status === "thinking"}
              aria-label={status === "recording" ? "Send voice note" : "Record voice note"}
              className={`relative grid h-24 w-24 place-items-center rounded-full border text-gold transition-transform active:scale-95 disabled:opacity-60 ${
                inConversation ? "border-gold bg-elevated" : "mic-idle border-hairline bg-elevated hover:border-gold"
              }`}
            >
              {status === "recording" ? (
                <Square size={26} className="text-danger" />
              ) : status === "thinking" ? (
                <Loader size={26} className="animate-spin" />
              ) : (
                <Mic size={30} />
              )}
            </button>
          </div>
        )}
        <p className="text-center text-sm font-medium text-primary">
          {!recordSupported ? "Type to the waiter below" : STATUS_LABEL[status]}
        </p>
        {inConversation && (
          <button onClick={stop} className="btn-ghost px-4 py-1.5 text-sm">
            End voice chat
          </button>
        )}
      </div>

      {error && (
        <div className="mb-2 flex items-start gap-2 rounded-xl border border-hairline bg-base/40 px-3 py-2 text-sm text-danger">
          <AlertCircle size={15} className="mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div ref={logRef} className="flex-1 overflow-y-auto rounded-xl border border-hairline bg-base/40 p-3">
        {transcript.length === 0 ? (
          <p className="text-center text-sm text-muted">
            Tap the mic, say your order out loud, then tap again to send — e.g. “a salted popcorn and a cold coffee.”
          </p>
        ) : (
          <ul className="space-y-2">
            {transcript.map((line, i) => (
              <li key={i} className={line.role === "you" ? "text-right" : "text-left"}>
                <span className="mb-0.5 block text-[11px] uppercase tracking-wide text-muted">
                  {line.role === "you" ? "You" : "Waiter"}
                </span>
                <span
                  className={`inline-block rounded-xl px-3 py-1.5 text-sm ${
                    line.role === "you" ? "bg-gold text-base" : "bg-elevated text-primary"
                  }`}
                >
                  {line.text}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {recordSupported && (
        <button
          onClick={() => setShowText((v) => !v)}
          className="mt-2 flex items-center justify-center gap-1.5 text-xs text-muted transition-colors hover:text-gold"
        >
          <Keyboard size={13} /> {showText ? "Hide typing" : "Type instead"}
        </button>
      )}
      {showText && (
        <form onSubmit={submitText} className="mt-2 flex gap-2">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Type your order…"
            className="flex-1 rounded-xl border border-hairline bg-surface px-3 py-2 text-sm text-primary outline-none transition-colors placeholder:text-muted/60 focus:border-gold"
          />
          <button type="submit" className="btn-gold flex items-center gap-1 px-3 text-sm">
            <Send size={15} />
          </button>
        </form>
      )}
    </div>
  );
}
