import { useState } from "react";
import { Plus } from "lucide-react";
import { CATEGORIES } from "@shared/constants.js";
import { inr } from "../lib/format.js";

const FILTERS = ["All", ...CATEGORIES];

function SkeletonCard() {
  return (
    <div className="rounded-2xl border border-hairline bg-surface p-4">
      <div className="skeleton mb-3 h-4 w-2/3 rounded" />
      <div className="skeleton mb-2 h-3 w-full rounded" />
      <div className="skeleton mb-4 h-3 w-1/2 rounded" />
      <div className="skeleton h-8 w-20 rounded-lg" />
    </div>
  );
}

export default function MenuGrid({ menu, loading, onAdd }) {
  const [filter, setFilter] = useState("All");
  const items = menu.filter((m) => m.active && (filter === "All" || m.category === filter));

  return (
    <div className="flex h-full flex-col">
      <div className="mb-4 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f}
            data-active={filter === f}
            onClick={() => setFilter(f)}
            className="pill px-3.5 py-1.5 text-sm"
          >
            {f}
          </button>
        ))}
      </div>

      <div className="grid flex-1 grid-cols-1 content-start gap-3 overflow-y-auto pr-1 sm:grid-cols-2">
        {loading
          ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
          : items.map((item) => {
              const out = item.stock <= 0;
              const low = item.stockLevel === "low";
              return (
                <div
                  key={item.id + filter}
                  className={`fade-rise flex flex-col rounded-2xl border border-hairline bg-surface p-4 transition-colors ${
                    out ? "opacity-40" : "hover:border-gold/40"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-heading text-base text-primary">{item.name}</h3>
                    {out ? (
                      <span className="shrink-0 rounded-full bg-base px-2 py-0.5 text-[11px] text-danger">
                        Sold out
                      </span>
                    ) : low ? (
                      <span className="shrink-0 rounded-full bg-base px-2 py-0.5 text-[11px] text-amber">
                        Only {item.stock} left
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-1 line-clamp-2 text-sm text-muted">{item.description}</p>
                  <div className="mt-auto flex items-center justify-between pt-3">
                    <span className="font-medium text-primary">{inr(item.price)}</span>
                    <button
                      disabled={out}
                      onClick={() => onAdd(item)}
                      className="btn-gold flex items-center gap-1 px-3 py-1.5 text-sm disabled:cursor-not-allowed"
                    >
                      <Plus size={14} /> Add
                    </button>
                  </div>
                </div>
              );
            })}
      </div>
    </div>
  );
}
