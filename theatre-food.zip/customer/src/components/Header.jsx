import { Link, useNavigate } from "react-router-dom";
import { ShoppingBag, Clock, ExternalLink, Armchair } from "lucide-react";
import { getSettings } from "@shared/data.js";
import { useLive } from "../lib/useLive.js";
import { useCart } from "../lib/CartContext.jsx";

const ADMIN_URL = "http://localhost:5174";

export default function Header() {
  const settings = useLive(() => getSettings());
  const { count } = useCart();
  const navigate = useNavigate();
  const seat = sessionStorage.getItem("tfo_seat");

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-hairline bg-base/90 px-4 py-3 backdrop-blur sm:px-6">
      <Link to={seat ? "/order" : "/"} className="font-heading text-lg text-primary transition-colors hover:text-gold">
        {settings.theatreName}
      </Link>

      {seat && (
        <span className="hidden items-center gap-1.5 text-sm text-muted sm:flex">
          <Armchair size={15} className="text-gold" /> Seat {seat}
        </span>
      )}

      <div className="flex items-center gap-1.5">
        <button
          onClick={() => navigate("/order")}
          className="btn-ghost relative flex items-center gap-1.5 px-3 py-2 text-sm"
          aria-label="Cart"
        >
          <ShoppingBag size={16} />
          {count > 0 && (
            <span className="absolute -right-1.5 -top-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-gold px-1 text-xs font-medium text-base">
              {count}
            </span>
          )}
        </button>
        <button
          onClick={() => navigate("/history")}
          className="btn-ghost flex items-center gap-1.5 px-3 py-2 text-sm"
          aria-label="Order history"
        >
          <Clock size={16} />
        </button>
        <a
          href={ADMIN_URL}
          target="_blank"
          rel="noreferrer"
          className="ml-1 hidden items-center gap-1 text-xs text-muted transition-colors hover:text-gold sm:flex"
        >
          Staff portal <ExternalLink size={12} />
        </a>
      </div>
    </header>
  );
}
