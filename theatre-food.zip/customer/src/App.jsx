import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { CartProvider } from "./lib/CartContext.jsx";
import Header from "./components/Header.jsx";
import CheckIn from "./pages/CheckIn.jsx";
import Order from "./pages/Order.jsx";
import Status from "./pages/Status.jsx";
import History from "./pages/History.jsx";

export default function App() {
  const location = useLocation();
  const showHeader = location.pathname !== "/";

  return (
    <CartProvider>
      <div className="min-h-full flex flex-col">
        {showHeader && <Header />}
        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={<CheckIn />} />
            <Route path="/order" element={<Order />} />
            <Route path="/status/:id" element={<Status />} />
            <Route path="/history" element={<History />} />
          </Routes>
        </AnimatePresence>
      </div>
    </CartProvider>
  );
}
