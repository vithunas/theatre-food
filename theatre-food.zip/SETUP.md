# Setup & Run — quick checklist

This is a 3-app project (customer / admin / kitchen) that runs locally.

## 0. Prerequisite (install once)
- **Node.js 18 or newer** — https://nodejs.org (this includes `npm`).
  Verify in a terminal: `node -v`

## 1. Get the files in place
- If you received a **.zip**: unzip it to a normal folder, e.g. `C:\Users\<you>\theatre-food`.
  (Don't run it from inside the zip.)
- Open this folder in **Claude Code** (or any terminal) as the working directory.

## 2. Install dependencies
```bash
npm install
```
This installs all three apps at once (npm workspaces). Takes a minute.

## 3. Run it
```bash
npm run dev
```
Then open **http://localhost:5173** in **Chrome or Edge**.
- Admin dashboard: http://localhost:5174
- Kitchen display: http://localhost:5175

Keep the terminal open while using the app. Allow the microphone when asked, to order by voice.

## 4. (Optional) Turn on the free AI voice waiter
The app works immediately with a built-in browser voice. For the smarter
**Groq + Whisper + natural voice** waiter:
1. Create your own env file:
   ```bash
   copy .env.example .env      # macOS/Linux: cp .env.example .env
   ```
2. Get a **free** key (no billing) at https://console.groq.com/keys
3. Open `.env` and paste it on the `GROQ_API_KEY=` line — **edit the file, don't paste the key into chat.**
4. Stop the app (Ctrl+C) and run `npm run dev` again. The waiter badge will read **"FREE AI"**.

## If something doesn't work
- **`npm` not found** → install Node.js (step 0), reopen the terminal.
- **Port already in use** → close the other program on 5173/5174/5175, or restart the terminal.
- **Mic not working** → use Chrome/Edge, and click **Allow** on the microphone prompt
  (or the lock icon in the address bar → Microphone → Allow).
- **Page won't load** → use `http://localhost:5173` exactly (not `https`), in an Incognito window.

## Asking Claude Code to do it for you
Once the folder is open in Claude Code, you can simply say:
> "Install the dependencies and run this project, then give me the localhost link."
